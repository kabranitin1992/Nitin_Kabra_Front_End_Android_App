package com.example.app_nitin;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {

	protected static final int REQUEST_OK = 1;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		findViewById(R.id.button1).setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		 Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
         i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "en-US");
         try {
             startActivityForResult(i, REQUEST_OK);
         } catch (Exception e) {
        	 Toast.makeText(this, "Error initializing speech to text engine.", Toast.LENGTH_LONG).show();
         }
	}
	
	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==REQUEST_OK  && resultCode==RESULT_OK) {
        	final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
    				this);
    		
        	ArrayList<String> thingsYouSaid = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        	//((TextView)findViewById(R.id.text1)).setText(thingsYouSaid.get(0));
        	if (thingsYouSaid.contains("about me")){
        		alertDialogBuilder.setMessage("Name: Nitin Kabra \n University: University of North Carolina at Charlotte\n Degree: M.S in Information Technology\n");
        		thingsYouSaid.clear();
        		alertDialogBuilder.show();
        	}else if (thingsYouSaid.contains("framework")){
        		alertDialogBuilder.setMessage("Android is the most widely used OS for handheld devices. \n Provides Easy access to thousands of applications via the Google Android Android App Market \n");
        		thingsYouSaid.clear();
        		alertDialogBuilder.show();
        	}else if (thingsYouSaid.contains("about app")){
        		alertDialogBuilder.setMessage("Speech Recognization is the most user friendly approach. \n Access to data items using speech is faster and more enjoyable");
        		thingsYouSaid.clear();
        		alertDialogBuilder.show();
        	}else if (thingsYouSaid.contains("why excited")){
        		alertDialogBuilder.setMessage("Its a great opportunity to work with Zappos as it is recognized as one of the 100 best companies to work for.\n I am interested in working for a front end development position at Zappos.");
        		thingsYouSaid.clear();
        		alertDialogBuilder.show();
        	}else{
        		alertDialogBuilder.setMessage("Speak Again");
        		thingsYouSaid.clear();
        		alertDialogBuilder.show();
        	}
        }
    }

}
