/** Automatically generated file. DO NOT MODIFY */
package com.example.app_nitin;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}